package com.example.springboot.servicelmpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springboot.exception.ResourceNotFoundException;
import com.example.springboot.model.Bank;
import com.example.springboot.repository.BankRepository;
import com.example.springboot.service.BankService;


@Service
public class BankServiceImpl implements BankService {

    @Autowired
    private BankRepository bankRepository;

    public BankServiceImpl(BankRepository bankRepository) {
        super();
        this.bankRepository = bankRepository;
    }
    

    @Override
    public Bank getBankDetailById(long bankId) {
        Optional<Bank> bankOptional = bankRepository.findById(bankId);
        return bankOptional.orElseThrow(() -> new ResourceNotFoundException("Bank", "Id", bankId));
    }

    @Override
    public List<Bank> getAllBankDetail() {
        return bankRepository.findAll();
    }

    @Override
    public Bank createBankDetail(Bank bank) {
        return bankRepository.save(bank);
    }

    @Override
    public Bank updateBankDetail(long bankId, Bank bank) {
        Optional<Bank> existingBank = bankRepository.findById(bankId);
        if (existingBank.isPresent()) {
            // Update the existing bank details with the new values
            Bank updatedBank = existingBank.get();
            updatedBank.setFirstName(bank.getFirstName());
            updatedBank.setLastName(bank.getLastName());
            updatedBank.setDistrict(bank.getDistrict());
            updatedBank.setState(bank.getState());
            updatedBank.setCardNumber(bank.getCardNumber());
            updatedBank.setExpYear(bank.getExpYear());
            updatedBank.setCvv(bank.getCvv());

            return bankRepository.save(updatedBank);
        } else {
            throw new ResourceNotFoundException("Bank", "Id", bankId);
        }
    }

    @Override
    public void deleteBank(long bankId) {
        Optional<Bank> existingBank = bankRepository.findById(bankId);
        if (existingBank.isPresent()) {
            bankRepository.deleteById(bankId);
        } else {
            throw new ResourceNotFoundException("Bank", "Id", bankId);
        }
    }
}