package com.example.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springboot.model.Bank;



public interface BankRepository extends JpaRepository<Bank,Long>{

	Bank findByCardNumberAndExpYearAndCvv(String cardNumber, String expYear, int cvv);

}
