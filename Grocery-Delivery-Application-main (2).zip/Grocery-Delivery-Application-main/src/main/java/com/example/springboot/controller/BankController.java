package com.example.springboot.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.springboot.model.Bank;
import com.example.springboot.service.BankService;

import java.util.List;

@RestController
@RequestMapping("/api/banks")
public class BankController {

    private final BankService bankService;

    @Autowired
    public BankController(BankService bankService) {
        this.bankService = bankService;
    }

    @GetMapping("/{bankId}")
    public ResponseEntity<Bank> getBankDetailById(@PathVariable long bankId) {
        Bank bank = bankService.getBankDetailById(bankId);
        return new ResponseEntity<>(bank, HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Bank>> getAllBankDetail() {
        List<Bank> banks = bankService.getAllBankDetail();
        return new ResponseEntity<>(banks, HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<Bank> createBankDetail(@RequestBody Bank bank) {
        Bank createdBank = bankService.createBankDetail(bank);
        return new ResponseEntity<>(createdBank, HttpStatus.CREATED);
    }

    @PutMapping("/{bankId}")
    public ResponseEntity<Bank> updateBankDetail(@PathVariable long bankId, @RequestBody Bank bank) {
        Bank updatedBank = bankService.updateBankDetail(bankId, bank);
        return new ResponseEntity<>(updatedBank, HttpStatus.OK);
    }

    @DeleteMapping("/{bankId}")
    public ResponseEntity<Void> deleteBank(@PathVariable long bankId) {
        bankService.deleteBank(bankId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
