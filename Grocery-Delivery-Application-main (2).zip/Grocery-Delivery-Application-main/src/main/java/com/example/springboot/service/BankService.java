package com.example.springboot.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.springboot.model.Bank;



@Service
public interface BankService {
	  Bank getBankDetailById(long bankId);
	    List<Bank> getAllBankDetail();
	    Bank createBankDetail(Bank bank);
	    Bank updateBankDetail(long bankId, Bank bank);
	    void deleteBank(long bankId);
}

